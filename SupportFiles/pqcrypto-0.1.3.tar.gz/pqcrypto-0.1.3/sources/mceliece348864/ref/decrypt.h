#ifndef DECRYPT_H
#define DECRYPT_H
/*
  This file is for Nieddereiter decryption
*/

int decrypt(unsigned char * /*e*/, const unsigned char * /*sk*/, const unsigned char * /*c*/);

#endif

